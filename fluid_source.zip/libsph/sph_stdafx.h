// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

// C Runtime library
#include <stdio.h>
#include <tchar.h>
#include <time.h>
#include <math.h>
#include <assert.h>

// CPP Runtime library
#include <string>
#include <vector>
#include <list>
#include <map>
#include <limits>
#include <stack>
#include <set>
#include <algorithm>

#include "sph_interface.h"
